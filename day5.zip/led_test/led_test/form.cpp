#include "form.h"
#include "ui_form.h"
#include "widget.h"
Form::Form(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Form)
  ,main_ui(nullptr)
{
    ui->setupUi(this);
}

Form::~Form()
{
    delete ui;
}

void Form::on_pushButton_clicked()
{
    //跳到主界面
    this->hide();
    if(main_ui){
        main_ui->show();

    }else{
        qDebug()<<"main_ui error"<<endl;
    }

}
void Form ::newpicture(){
    qDebug()<<"New picture received!";
}
void Form ::timout(){
    qDebug()<<"Timer timeout!";
}
