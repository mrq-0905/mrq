#include "widget.h"
#include "ui_widget.h"

#include <qdebug.h>
#include<QPixmap>
#include"form.h"

Widget::Widget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Widget)
    ,time(new QTimer(this))//初始化
    ,form_ui(nullptr)
{
    ui->setupUi(this); // <--- 在这里后面添加

    // --- 开始美化代码 ---

    // 1. 设置主窗口背景：柔和的蓝粉渐变 (类似 Instagram 风格)
    // #a8edea 是浅青色，#fed6e3 是浅粉色
    this->setStyleSheet(
        "QWidget {"
        "   background-color: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #a8edea, stop:1 #fed6e3);"
        "   color: #555555;" // 全局文字颜色设为深灰，保证在浅色背景下清晰可见
        "}"

        // 2. 统一按钮样式：白色底 + 圆角 + 阴影
        // 这样按钮在粉色背景下会显得很有层次感
        "QPushButton {"
        "   background-color: rgba(255, 255, 255, 220);" // 半透明白色
        "   border-radius: 10px;"                        // 圆角
        "   border: 1px solid rgba(255, 255, 255, 100);" // 极细的白色边框
        "   padding: 8px;"                               // 内边距
        "   font-size: 14px;"                            // 字体大小
        "   font-weight: bold;"                          // 加粗
        "   color: #ff758c;"                             // 文字颜色用深粉色，呼应背景
        "}"

        // 3. 按钮悬停效果：鼠标放上去变深色一点
        "QPushButton:hover {"
        "   background-color: rgba(255, 255, 255, 255);" // 变成纯白
        "   border: 1px solid #ff758c;"                  // 边框变色
        "}"

        // 4. 按钮按下效果
        "QPushButton:pressed {"
        "   background-color: #ff9a9e;"                  // 按下变成粉色
        "   color: white;"                               // 文字变白
        "}"
    );
    // --- 结束美化 ---





    ui->horizontalSlider->setRange(0,100);


    connect(&myevent,&fsmpEvents::keyPressed,this,&Widget::pushbutton);

    connect(time,&QTimer::timeout,this,&Widget::timout);
    time->start(1000);
}

Widget::~Widget()
{
    delete ui;
}


void Widget::on_pushButton_clicked()
{
    if(ui->pushButton->text()=="开灯"){

        myled.on(fsmpLeds::LED1);
        ui->pushButton->setText("关灯");
    }
    else{
        myled.off(fsmpLeds::LED1);
        ui->pushButton->setText("开灯");
    }
}


void Widget::on_pushButton_2_clicked()
{

}


void Widget::on_checkBox_stateChanged(int arg1)
{
    if(arg1){

        myled.on(fsmpLeds::LED2);    }
    else
    {

        myled.off(fsmpLeds::LED2);
    }
}



void Widget::on_checkBox_2_stateChanged(int arg1)
{
    if(arg1){

        mybeeper.setRate(5000);
        mybeeper.start();
    }
    else
    {
        mybeeper.stop();
    }
}


void Widget::on_horizontalSlider_valueChanged(int value)
{
    qDebug() << ui->horizontalSlider->value();

    mybeeper.setRate(value);
    mybeeper.start();

    ui->progressBar->setValue(ui->horizontalSlider->value());
}


void Widget::on_checkBox_3_stateChanged(int arg1)
{
    if(arg1){

            myfan.setSpeed(100);
            myfan.start();
        }
        else
        {
            myfan.stop();
        }
}
void Widget:: pushbutton(int num){

  switch(num){

  case 1:
      myled.on(fsmpLeds::LED1);
      break;
  case 2:
      myled.on(fsmpLeds::LED2);
      break;
  case 3:
      myled.on(fsmpLeds::LED3);
      break;
  default:
      break;
  }

};
void Widget:: timout(){
    ui->doubleSpinBox->setValue(myth.temperature());
    ui->doubleSpinBox_2->setValue(myth.humidity());
}


void Widget::on_pushButton_3_clicked()
{
    if(!form_ui){
        form_ui = new Form(nullptr);
    }
    this->hide();
    form_ui->show();

}

